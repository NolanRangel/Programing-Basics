var ridersHeigth = 0;  //input variable for riders heigth in inches
var ridersAge = 0;  //input variable for rider age in years

var requiredHeigth = 52; //Var heigth will be used within a boolean to check if child is tall enough
var requiredAge = 10; // Var age will be used within a boolean to check if child is old enough


// Both heigth AND age are required
function canYouRideTheRollerCoaster() {
	if (ridersHeigth > requiredHeigth && ridersAge > requiredAge) {
		console.log("Get on that ride, kiddo!");
	}
	else if (ridersHeigth < requiredHeigth && ridersAge < requiredAge) {
		console.log("Sorry kiddo. Maybe next year.");
	}

}

// Either heigth OR age are required
function canYouRideTheRollerCoaster() {
	if (ridersHeigth > requiredHeigth || ridersAge > requiredAge) {
		console.log("Get on that ride, kiddo!");
	}
	else if (ridersHeigth < requiredHeigth || ridersAge < requiredAge) {
		console.log("Sorry kiddo. Maybe next year.");
	}

}